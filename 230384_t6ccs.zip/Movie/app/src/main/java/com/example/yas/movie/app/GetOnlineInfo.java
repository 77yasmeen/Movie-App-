package com.example.yas.movie.app;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;

import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by yas on 8/16/2016.
 */
public class GetOnlineInfo extends AsyncTask <String , ArrayList<MovieObject>,ArrayList<MovieObject>> {
    Context context;
    String baseUrl ;
    GridViewListener gridViewListener ;
    GridviewAdapter GridViewAdapter ;
    ArrayList<MovieObject>Movie = new ArrayList<MovieObject>();

    public GetOnlineInfo(GridviewAdapter g , String baseUrl){
        GridViewAdapter = g ;
        this.baseUrl=baseUrl;
    }
    @Override
    protected ArrayList<MovieObject> doInBackground(String ... params) {
        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;
        String JsonStr = null;

        String format = "jeson";
        Jsonparsing json ;
        try{



            String api_key = "api_key";
            Uri uribuiltConnection = Uri.parse(baseUrl).buildUpon().appendQueryParameter(api_key,"bada7317d8ff3f0975dbcb24d59e5515").build();

            //open connection
            URL url = new URL(uribuiltConnection.toString());
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            //get input stream
            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer = new StringBuffer();
            if(inputStream == null){
                return null;

            }
            reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                // But it does make debugging a *lot* easier if you print out the completed
                // buffer for debugging.
                buffer.append(line + "\n");
            }
            if(buffer.length() == 0){
                return null;
            }
            JsonStr = buffer.toString();


        }catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                }
            }
       if(JsonStr!=null){
        json = new Jsonparsing(JsonStr);
        try {
            Movie = json.getMovieObjects();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            return json.getMovieObjects();
        } catch (JSONException e) {
            e.printStackTrace();
        }}

        return null;
    }}
    public void onPostExecute(ArrayList<MovieObject> Movies){
        if(Movies != null && !Movies.isEmpty()) {
            GridViewAdapter.update(Movies);
            GridViewAdapter.notifyDataSetChanged();
        }

    }
}
