package com.example.yas.movie.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by yas on 9/10/2016.
 */
public class ReviewAdapter extends ArrayAdapter<ReviewObject>{
    public ReviewAdapter(Context context, ArrayList<ReviewObject> review) {
        super(context,0 ,review);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        ReviewObject r = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_layout, parent, false);
        }
        // Lookup view for data population
        TextView auther = (TextView) convertView.findViewById(R.id.auther);
        TextView id = (TextView) convertView.findViewById(R.id.id);
        TextView url = (TextView) convertView.findViewById(R.id.url);
        TextView review = (TextView) convertView.findViewById(R.id.review);

        // Populate the data into the template view using the data object
        auther.setText("Auther : "+r.getAuther());
        id.setText("Id : "+r.getId());
        review.setText("Review :"+r.getContent());
        url.setText("Url : "+r.getUrl());
        // Return the completed view to render on screen
        return convertView;
    }

}
