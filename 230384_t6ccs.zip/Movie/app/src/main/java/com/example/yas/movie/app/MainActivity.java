package com.example.yas.movie.app;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements GridViewListener{
    GetOnlineInfo twoPane ;
    public static final String MyPREFERENCES = "MyPrefs" ;
    String m_t;
    String s;
    boolean b =false ;
    //SharedPreferences.Editor editor;
    public static final String menu = "most_popular";
    SharedPreferences sharedpreferences;
    SharedPreference sharedPreference;
    ArrayList<MovieObject>favorites = new ArrayList<MovieObject>();
    boolean mTwoPane ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FrameLayout flPanel2 = (FrameLayout)findViewById(R.id.fLpanel2);
        if(null == flPanel2){
         mTwoPane = false;
        }else{
            mTwoPane=true;
        }



        GridViewFragment gridViewFragment = new GridViewFragment(new GridviewAdapter(this.getApplicationContext(),new ArrayList<MovieObject>()) , new GetOnlineInfo(new GridviewAdapter( ) , "http://api.themoviedb.org/3/movie/popular?"),0,new ArrayList<MovieObject>());
          gridViewFragment.setNameListener(this);
            getSupportFragmentManager().beginTransaction().replace(R.id.activity_main, gridViewFragment).commit();


        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        return true;
    }
    public void SharedPreferenceClick(View view){
        m_t=menu.toString();

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        ArrayList<MovieObject> Favorit_Movie = new ArrayList<MovieObject>();
        GridViewFragment gridViewFragment2 = null;
        int id = item.getItemId();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        //noinspection SimplifiableIfStatement
        switch (item.getItemId()) {

            case R.id.most_popular:
                GridviewAdapter g= new GridviewAdapter(this.getApplicationContext(),new ArrayList<MovieObject>());
                GetOnlineInfo g1 = new GetOnlineInfo(g ,"http://api.themoviedb.org/3/movie/popular?");
                g1.baseUrl="https://api.themoviedb.org/3/movie/popular?";
                gridViewFragment2 = new GridViewFragment(g,g1,0,new ArrayList<MovieObject>());
                g1.execute();

                break;

            case R.id.top_rated:


                GridviewAdapter gA= new GridviewAdapter(getApplicationContext(),new ArrayList<MovieObject>());
                GetOnlineInfo gB = new GetOnlineInfo(gA,"http://api.themoviedb.org/3/movie/top_rated?");
                gB.execute();
                 gridViewFragment2 = new GridViewFragment(gA,gB,1,new ArrayList<MovieObject>());
                break;
            case R.id.favorit:
                sharedPreference = new SharedPreference();
                favorites = sharedPreference.getFavorites(getApplicationContext());
                GridviewAdapter gridviewAdapter = new GridviewAdapter(getApplicationContext(),favorites);
                gridviewAdapter.update(favorites);
                 gridViewFragment2 = new GridViewFragment(gridviewAdapter,2,favorites);


                break;
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.activity_main, gridViewFragment2).commit();
     return super.onOptionsItemSelected(item);
    }

    public boolean getPane(){return mTwoPane;}
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void setSelectedMovie(MovieObject movie) {
        if(mTwoPane){
          DetailFragment detailFragment = new DetailFragment();
            Bundle extras = new Bundle();
            extras.putString(Intent.EXTRA_TEXT,movie.getORIGINAL_TITLE()+"_"+movie.getRELEASE_DATE()+"_"+movie.getVOT_AVERAGE()+"_"+movie.getOVER_VIEW()+"_"+movie.getID()+"_"+movie.getPOSTER_PATH());
           detailFragment.setArguments(extras);
            getSupportFragmentManager().beginTransaction().replace(R.id.fLpanel2 ,detailFragment).commit();


        }else {
          Intent intent = new Intent(this ,DetailActivity.class).putExtra(Intent.EXTRA_TEXT,movie.getORIGINAL_TITLE()+"_"+movie.getRELEASE_DATE()+"_"+movie.getVOT_AVERAGE()+"_"+movie.getOVER_VIEW()+"_"+movie.getID()+"_"+movie.getPOSTER_PATH());
                 startActivity(intent);

    }}
}
