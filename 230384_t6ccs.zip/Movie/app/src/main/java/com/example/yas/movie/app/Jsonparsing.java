package com.example.yas.movie.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by yas on 8/16/2016.
 */
public class Jsonparsing {
    String jsonstr ;
    ArrayList<MovieObject> MovieObjectf = new ArrayList<MovieObject>();
    public Jsonparsing(String jsonStr) {
        this.jsonstr=jsonStr;
    }
   public ArrayList<MovieObject> getMovieObjects () throws JSONException {
       String RESULTS        = "results";
       String poster_path    = "poster_path";
       String ID             = "id";
       String original_title = "original_title";
       String overview       = "overview";
       String release_date   = "release_date";
       String vote_average   = "vote_average";

       MovieObject MO = null;
       JSONObject Movies = new JSONObject(this.jsonstr);
       JSONArray  MovieArray = Movies.getJSONArray(RESULTS);
       MovieObjectf.clear();
       for (int i =0 ;i<MovieArray.length();i++){
            MO = new MovieObject();
           JSONObject  objectData = MovieArray.getJSONObject(i);

           MO.setPOSTER_PATH(objectData.getString(poster_path));  ;
           MO.setORIGINAL_TITLE(objectData.getString(original_title));
           MO.setOVER_VIEW(objectData.getString(overview));
           MO.setRELEASE_DATE(objectData.getString(release_date));
           MO.setVOT_AVERAGE(objectData.getString(vote_average));
           MO.setID(objectData.getString(ID));
           MovieObjectf.add(MO);

       }
       return MovieObjectf ;
   }
}
