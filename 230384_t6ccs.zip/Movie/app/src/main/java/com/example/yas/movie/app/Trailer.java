package com.example.yas.movie.app;

/**
 * Created by yas on 9/5/2016.
 */
public class Trailer {
    private  String key ;
    public Trailer (){}
    public Trailer(String key){
        this.key=key;
    }
    public void setKey(String key){
        this.key =key;
    }
    public String getKey(){return key;}
}
