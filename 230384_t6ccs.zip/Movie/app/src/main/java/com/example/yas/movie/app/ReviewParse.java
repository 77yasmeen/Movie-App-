package com.example.yas.movie.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by yas on 9/9/2016.
 */
public class ReviewParse {
    String result="results";
     String id ="id";
    String resjson;
     String auther="author" ;
     String content ="content";
    String url = "url";
    ReviewObject reviewObject ;
    ArrayList<ReviewObject> reviewObjectArrayList=new ArrayList<ReviewObject>() ;
   public ReviewParse (String result){
       this.resjson=result;
   }
    public ArrayList<ReviewObject> getReviews () throws JSONException {

        JSONObject r = new JSONObject(this.resjson);
        JSONArray MovieArray = r.getJSONArray(result);

        reviewObject=null;
        for (int i =0 ;i<MovieArray.length();i++){
            reviewObject =new ReviewObject();

            JSONObject  objectData = MovieArray.getJSONObject(i);

            reviewObject.setContent(objectData.getString(content));

            reviewObject.setId(objectData.getString(id));
            reviewObject.setOuther(objectData.getString(auther));
            reviewObject.setUrl(objectData.getString(url));


            reviewObjectArrayList.add(reviewObject);

        }
        return reviewObjectArrayList ;

    }

}
