package com.example.yas.movie.app;

import android.annotation.TargetApi;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by yas on 8/29/2016.
 */
@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class SettingFragment extends PreferenceFragment {
    public static final String mypreference = "mypref";

    boolean b ;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.menu_setting);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());

        String test = prefs.getString("most_popular", String.valueOf(prefs.contains("nn")));



    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_setting, container, false);

        return rootView;
    }

}
