package com.example.yas.movie.app;

/**
 * Created by yas on 9/8/2016.
 */
public class ReviewObject {

    private String review ;
    private String id ;
    private String auther ;
    private String content ;
    private String url;

    public void setReview(String review){
        this.review=review;
    }
    public void setUrl(String url){this.url=url;}
    public String getUrl(){return url;}
    public String getContent(){
        return content;
    }
    public void setId(String id){
        this.id=id;
    }
    public String getId(){
        return id;
    }
    public void setOuther(String auther){
        this.auther=auther;
    }
    public String getAuther(){
        return auther;
    }
    public void setContent(String content){
        this.content=content;
    }
}
