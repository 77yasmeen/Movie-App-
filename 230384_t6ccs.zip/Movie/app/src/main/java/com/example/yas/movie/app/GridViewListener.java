package com.example.yas.movie.app;

/**
 * Created by yas on 9/15/2016.
 */
public interface GridViewListener {
    public void setSelectedMovie(MovieObject movie);
}
