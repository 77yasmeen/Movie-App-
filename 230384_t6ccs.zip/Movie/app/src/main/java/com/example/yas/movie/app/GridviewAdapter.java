package com.example.yas.movie.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by yas on 8/16/2016.
 */
public class GridviewAdapter extends BaseAdapter {
    List<MovieObject> movieObject = new ArrayList<MovieObject>();
    SharedPreference sharedPreference;

    Context context;

    public GridviewAdapter() {
    }

    public GridviewAdapter(Context context, ArrayList<MovieObject> movieObject) {
        this.movieObject = movieObject;
        this.context = context;

        sharedPreference = new SharedPreference();

    }

    @Override
    public int getCount() {
        if (movieObject != null) {
            return movieObject.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return movieObject.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void update(ArrayList<MovieObject> movieObjects) {
        this.movieObject = movieObjects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        boolean b = true;
        ImageView imageView = null;


        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.image_view,null);
            imageView = (ImageView)convertView.findViewById(R.id.imageView);

        } else {
            imageView = (ImageView) convertView;

        }
        int width = context.getResources().getDisplayMetrics().widthPixels;

        Picasso.with(context).load("http://image.tmdb.org/t/p/" + "w185" + movieObject.get(position).getPOSTER_PATH())
                .into(imageView);

        return imageView;
    }

}
