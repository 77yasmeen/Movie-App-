package com.example.yas.movie.app;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

/**
 * Created by yas on 8/24/2016.
 */
public class DetailFragment extends Fragment  {
    boolean isFavorite = false;
    boolean isFavorite1 = false;
    String baseUrlVideo ="https://www.youtube.com/watch?v=";
    ArrayList<ReviewObject> re = new ArrayList<ReviewObject>();
    final String[] key = new String[1];
    SharedPreference sharedPreference =new SharedPreference();
  ArrayList<Trailer>test =new ArrayList<Trailer>();

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public View onCreateView(LayoutInflater inflater , ViewGroup container , Bundle savedInstanceState){
        ArrayList<MovieObject> favoritecheck = new ArrayList<MovieObject>();

        final ImageButton imageButton ;
        String [] str_array ;
        String title ;
        String date;
        String vote;
        String over_view;
        String poster_path;
        final MovieObject movieObject =new MovieObject();
        String id_i = null;
        String finalId_i = null;
        View rootView        = inflater.inflate(R.layout.text_over_view , container , false);
        ImageView imageView  = (ImageView)rootView.findViewById(R.id.small_image) ;
        TextView title1    = (TextView)rootView.findViewById(R.id.original_title);
        TextView date1     = (TextView)rootView.findViewById(R.id.release_date);
        TextView vote1     = (TextView)rootView.findViewById(R.id.vote_average);
        TextView over_view1    = (TextView)rootView.findViewById(R.id.over_view);
        Intent intent = getActivity().getIntent();
        final String overView = getArguments().getString(Intent.EXTRA_TEXT);
            str_array= overView.split("_");
            title = str_array[0];
            movieObject.setORIGINAL_TITLE(title);
            date = str_array[1];
            movieObject.setRELEASE_DATE(date);
            vote = str_array[2];
            movieObject.setVOT_AVERAGE(vote);
            over_view=str_array[3];
            movieObject.setOVER_VIEW(over_view);
            id_i = str_array[4];
            movieObject.setID(id_i);
           poster_path = str_array[5];

             finalId_i = id_i;

            title1.setText(title);
            date1.setText(date);
            vote1.setText(vote);
            over_view1.setText(over_view);
            ((TextView)rootView.findViewById(R.id.original_title)).setText(title);
            ((TextView)rootView.findViewById(R.id.release_date)).setText(date);
            ((TextView)rootView.findViewById(R.id.vote_average)).setText(vote);
            ((TextView)rootView.findViewById(R.id.over_view)).setText(over_view);
           String p = intent.getData()+"";
           movieObject.setPOSTER_PATH(poster_path);
            Picasso.with(getContext()).load("http://image.tmdb.org/t/p/"+"w185"+poster_path).into(imageView);
      //  }
        TextView textView ;
         int index = 0;
         imageButton = (ImageButton)rootView.findViewById(R.id.star_button);

         favoritecheck = sharedPreference.getFavorites(this.getContext());
        for (int i= 0;i<favoritecheck.size();i++){
            if(movieObject.getID().equals(favoritecheck.get(i).getID()) ){
                imageButton.setImageResource(R.drawable.sts);
                isFavorite = true;
                Log.e("favvvvvvvv",isFavorite+"");

                index = i;
            }
        }
        final int index2 = index;
        imageButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (isFavorite == true){
                    imageButton.setImageResource(R.drawable.aft);
                    sharedPreference.removeFavorite(getContext(),index2);
                    isFavorite1=false;
                }else if(isFavorite1 == false){
                    //add this movie to an array list and share it with main activity
                    imageButton.setImageResource(R.drawable.sts);
                    sharedPreference.addFavorite(getActivity(), movieObject);
                    isFavorite1=true;
                }
            }
        });
        final ListView listView = (ListView) rootView.findViewById(R.id.tralier_list);
        GetOnlineTrailer g =new GetOnlineTrailer(listView,"http://api.themoviedb.org/3/movie/"+ finalId_i +"/videos");
        g.execute();
        GetOnlineReviews rev = new GetOnlineReviews("http://api.themoviedb.org/3/movie/"+ finalId_i +"/reviews");
        rev.execute();
        try {
            re=rev.get();

        } catch (InterruptedException e) {
            e.printStackTrace();

        } catch (ExecutionException e) {
            e.printStackTrace();

        }
        ListView review = (ListView)rootView.findViewById(R.id.reviews);
        ReviewAdapter reviewAdapter = new ReviewAdapter(this.getContext() , re);

         reviewAdapter.addAll(re);
        review.setAdapter(reviewAdapter);
        ArrayList<Trailer>te = new ArrayList<Trailer>();
        try {
            te=g.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }


        TrailerAdapter trailerAdapter = new TrailerAdapter(this.getContext(),te);
        trailerAdapter.update(te);
        listView.setAdapter(trailerAdapter);
        setListViewHeightBasedOnChildren(listView);
        final ArrayList<Trailer> finalTe = te;



        return rootView;
    }

    public  void setListViewHeightBasedOnChildren(ListView listView){
        ListAdapter listAdapter = listView.getAdapter();

        int desiredWidth = ListView.MeasureSpec.makeMeasureSpec(listView.getWidth(), ListView.MeasureSpec.UNSPECIFIED);
        int totalHeight = 0;
        View view = null;
        for (int i = 0; i < listAdapter.getCount(); i++) {
            view = listAdapter.getView(i, view, listView);
            if (i == 0)
                view.setLayoutParams(new ViewGroup.LayoutParams(desiredWidth, ListView.LayoutParams.WRAP_CONTENT));

            view.measure(desiredWidth, ListView.MeasureSpec.UNSPECIFIED);
            totalHeight += view.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
    }
    public void saveStae(boolean isFavourite) {
        SharedPreferences aSharedPreferenes = getContext().getSharedPreferences(
                "Favourite", Context.MODE_PRIVATE);
        SharedPreferences.Editor aSharedPreferenesEdit = aSharedPreferenes
                .edit();
        aSharedPreferenesEdit.putBoolean("State", isFavourite);
        aSharedPreferenesEdit.commit();
    }

    public boolean readStae() {
        SharedPreferences aSharedPreferenes =getContext().getSharedPreferences(
                "Favourite", Context.MODE_PRIVATE);
        return aSharedPreferenes.getBoolean("State",true);
    }
}
