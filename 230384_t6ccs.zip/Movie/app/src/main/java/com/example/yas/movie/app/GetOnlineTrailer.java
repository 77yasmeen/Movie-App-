package com.example.yas.movie.app;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ListView;

import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by yas on 9/5/2016.
 */
public class GetOnlineTrailer extends AsyncTask<String, ArrayList<Trailer>, ArrayList<Trailer>> {

    Context context;
    String baseUrl ;
    TrailerAdapter trailerAdapter   ;
    ListView listView ;
      public GetOnlineTrailer(){}
    public GetOnlineTrailer(ListView listView, String baseUrl){
        this.baseUrl=baseUrl;
        this.listView=listView;
    }


    ArrayList<Trailer> trailers =new ArrayList<Trailer>();
    @Override
    protected ArrayList<Trailer> doInBackground(String... params) {
        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;
        String JsonStr = null;
        ArrayList<Trailer>t=new ArrayList<Trailer>();
       // TrailerAdapter t =new TrailerAdapter(listView)  ;

        String format = "jeson";
        TrailerParse trailer_parse;
        try {

            String api_key = "api_key";
            Uri uribuiltConnection = Uri.parse(baseUrl).buildUpon().appendQueryParameter(api_key,"bada7317d8ff3f0975dbcb24d59e5515").build();
            //open connection
            URL url = new URL(uribuiltConnection.toString());
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            //get input stream
            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer = new StringBuffer();
            if(inputStream == null){
                return null;
                //Log.d(TAG , "there is no data");

            }
            reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                // But it does make debugging a *lot* easier if you print out the completed
                // buffer for debugging.
                buffer.append(line + "\n");
            }
            if(buffer.length() == 0){
                // Log.d(TAG , "buffer.length == 0 ");
                return null;
            }
            JsonStr = buffer.toString();


        }  catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e("hi in finally ", "Error closing stream", e);
                }
            }


            trailer_parse = new TrailerParse(JsonStr);
           // trailerAdapter = new TrailerAdapter(this.listView);

            try {
                trailers = trailer_parse.getTrailerKeys();
            } catch (JSONException e) {
                e.printStackTrace();
                Log.e("yaaaaas","yaaaaaaas");
            }
            try {

                return  trailer_parse.getTrailerKeys();

            } catch (JSONException e) {
                e.printStackTrace();
            }

            return trailers;
        }

    }
    public void onPostExecute(){
        trailerAdapter.update(trailers);
        trailerAdapter.notifyDataSetChanged();

            }
}
