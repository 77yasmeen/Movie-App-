package com.example.yas.movie.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by yas on 9/5/2016.
 */
public class TrailerParse {
    String json;
    ArrayList<Trailer>trailerKey=new ArrayList<Trailer>();
    String RESULTS ="results";
    String KEY = "key";
    public TrailerParse(){}
    public TrailerParse(String json){
        this.json=json;
    }
    public ArrayList<Trailer> getTrailerKeys() throws JSONException {
        String key;
      if(this.json!=null){
        JSONObject Trailers = new JSONObject(this.json);
        JSONArray trailerArray = Trailers.getJSONArray(RESULTS);
       for (int i=0;i<trailerArray.length();i++){
            JSONObject  objectData = trailerArray.getJSONObject(i);
            Trailer t =new Trailer();
            t.setKey(objectData.getString(KEY));
            trailerKey.add(t);
       }}
        return trailerKey;

    }
}
