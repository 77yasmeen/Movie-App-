package com.example.yas.movie.app;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by yas on 9/5/2016.
 */
public class TrailerAdapter extends BaseAdapter {
    ArrayList<Trailer> trailers = new ArrayList<Trailer>();
    ListView listView;
    private FragmentManager  mPackManager;
    int position;
    Context context;


    public TrailerAdapter(Context context , ArrayList<Trailer> trailers ) {
        this.context=context;
        this.trailers = trailers;

    }


    public TrailerAdapter(ListView listView, ArrayList<Trailer> trailers) {
        this.trailers = trailers;
    }


    public void update(ArrayList<Trailer> trailers) {
        this.trailers = trailers;
    }



    @Override
    public int getCount() {
        return trailers.size();
    }

    @Override
    public Object getItem(int position) {
        return trailers.get(position).getKey();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        Trailer t = trailers.get(position);
        View v = convertView;
        if(v == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            v = inflater.inflate(R.layout.trailer_list, null);
        }
        TextView textView = (TextView)v.findViewById(R.id.trailer12);
        ImageButton imageButton = (ImageButton)v.findViewById(R.id.run1);
        textView.setText("Trailer"+(position+1));
        imageButton.setImageResource(R.drawable.run1);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onClick(View v) {

                context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(("https://www.youtube.com/watch?v=").concat(trailers.get(position).getKey()))));
            }
        });
        return v;


    }

}
