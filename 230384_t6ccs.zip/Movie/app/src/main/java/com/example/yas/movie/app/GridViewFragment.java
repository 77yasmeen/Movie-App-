package com.example.yas.movie.app;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;

import java.util.ArrayList;

/**
 * Created by yas on 8/16/2016.
 */

public class GridViewFragment extends Fragment {
    GridViewListener GVL;
    public String ID ;
    MovieObject m;
    public static GridviewAdapter GridViewAdapter ;
    GetOnlineInfo g ;
    View rootview = null;
    String posterPath;
    String overView;
    String release_date ;
    String vote_average;
    String original_title;
    ArrayList<MovieObject>movieObjects=new ArrayList<MovieObject>();

    int b ;
    public DetailFragment detailFragment ;
    public GridViewFragment(GridviewAdapter GridViewAdapter , GetOnlineInfo getOnlineInfo , int b , ArrayList<MovieObject> movieObjects){
        this.GridViewAdapter = GridViewAdapter;
        this.g=getOnlineInfo;
        this.movieObjects=movieObjects;
        this.b=b;
    }
    public GridViewFragment(GridviewAdapter grid ,int b, ArrayList<MovieObject> movieObjects1){
        this.GridViewAdapter=grid;
        this.b=b;
        this.movieObjects=movieObjects1;

    }
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        rootview = inflater.inflate(R.layout.grid_view , container , false);
        GridView  GridView = (GridView) rootview.findViewById(R.id.GridView);
        GridViewAdapter =new GridviewAdapter(getActivity(),movieObjects);
        if(b==0) {
            g = new GetOnlineInfo(GridViewAdapter, " http://api.themoviedb.org/3/movie/popular?");
            g.execute();
        }else if (b==1){
            g = new GetOnlineInfo(GridViewAdapter, " http://api.themoviedb.org/3/movie/top_rated?");
            g.execute();

        }else {
            Log.e("user choose favorite menu","favoorite");

        }

        GridView.setAdapter(GridViewAdapter );

        GridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                 m = (MovieObject) GridViewAdapter.getItem(position);
                posterPath = "http://image.tmdb.org/t/p/"+"w185"+m.getPOSTER_PATH();
                overView = m.getOVER_VIEW();
                original_title=m.getORIGINAL_TITLE();
                release_date=m.getRELEASE_DATE();
                vote_average=m.getVOT_AVERAGE();
                ID          =m.getID();
                ImageView imageView = (ImageView)rootview.findViewById(R.id.imageView);

                // GVL.setSelectedMovie(m);
                ((GridViewListener)getActivity()).setSelectedMovie(m);


            }
        });
        // Inflate the layout for this fragment
        return rootview;
    }
    public void setNameListener (GridViewListener gv){
        GVL=gv;
    }

}
