package com.example.yas.movie.app;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;

import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by yas on 9/8/2016.
 */
public class GetOnlineReviews extends AsyncTask<String , ArrayList<ReviewObject>,ArrayList<ReviewObject>> {
    Context context;
    String baseUrl ;
    ReviewObject r ;
    String result = null;

    ReviewParse reviewParse ;
    public GetOnlineReviews(String baseUrl){
        this.baseUrl=baseUrl;
    }
    @Override
    protected ArrayList<ReviewObject> doInBackground(String... params) {
        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;

        try {

            String api_key = "api_key";
            Uri uribuiltConnection = Uri.parse(baseUrl).buildUpon().appendQueryParameter(api_key,"bada7317d8ff3f0975dbcb24d59e5515").build();
            //open connection
            URL url = new URL(uribuiltConnection.toString());
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            //get input stream
            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer = new StringBuffer();
            if(inputStream == null){
                return null;

            }
            reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                // But it does make debugging a *lot* easier if you print out the completed
                // buffer for debugging.
                buffer.append(line + "\n");
            }
            if(buffer.length() == 0){
                return null;
            }
            result = buffer.toString();


        }  catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                }
            }
            ArrayList<ReviewObject> r = new ArrayList<ReviewObject>();

            if (result!=null) {
                reviewParse = new ReviewParse(result);
                try {
                    r = reviewParse.getReviews();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        return r;
    }
}

}
