package com.example.yas.movie.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by yas on 9/13/2016.
 */
public class SharedPreference {

    public SharedPreference() {
        super();


    }
    public static final String PREFS_NAME = "PRODUCT_APP";
    public static final String FAVORITES = "Product_Favorite";

    public void saveFavorites(Context context, List<MovieObject> favorites) {
        SharedPreferences settings;
        SharedPreferences.Editor editor;

        settings = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        editor = settings.edit();
        String jsonFavorites=null;
        Gson gson = new Gson();
        jsonFavorites = gson.toJson(favorites);
        Log.e("hi hi ", "in save favorite");

        editor.putString(FAVORITES, jsonFavorites);
        Log.e("hi hi ", jsonFavorites);

        editor.commit();
    }
    public void addFavorite(Context context, MovieObject Movie) {
        ArrayList<MovieObject> favorites = getFavorites(context);
        if (favorites == null)
            favorites = new ArrayList<MovieObject>();
        favorites.add(Movie);
        Log.e("hi","in add favorite");
        Log.e("hi hi ", Movie.getPOSTER_PATH()+"hi poster path");

        saveFavorites(context, favorites);
    }

    public ArrayList<MovieObject> getFavorites(Context context) {
        SharedPreferences settings;
        List<MovieObject> favorites;

        settings = context.getSharedPreferences(PREFS_NAME,
                Context.MODE_PRIVATE);

        if (settings.contains(FAVORITES)) {
            String jsonFavorites = settings.getString(FAVORITES, null);
            Gson gson = new Gson();
            MovieObject[] favoriteItems = gson.fromJson(jsonFavorites, MovieObject[].class);

            favorites = Arrays.asList(favoriteItems);


            favorites = new ArrayList<MovieObject>(favorites);

        } else
            return new ArrayList<>();

        return (ArrayList<MovieObject>) favorites;

    }
    public void removeFavorite(Context context, int i) {
        ArrayList<MovieObject> favorites = getFavorites(context);
        Log.e("dddddddd","done"+favorites.get(1).getPOSTER_PATH());
        ArrayList<MovieObject> a ;
        if (favorites != null) {
            favorites.remove(favorites.get(i));
            Log.e("dddddddd","done removed");
            a=favorites;
            saveFavorites(context, a);
        }}


}

